$(document).ready(function(){
    console.log('jj');
    // $('#licenceKey').on('change', function (event) {
    //     var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    //       var check=regex.test($('#licenceKey').val());
    //       if(check==false){
    //         $('#licenceKeyMSg').text('Please Enter Valid licenceKey');
    //         // $('#licenceKey').val(null)
    //         return false;
    //       }else{
    //          $('#licenceKeyMSg').text(null)
    //       }
       
    //   });
        
});