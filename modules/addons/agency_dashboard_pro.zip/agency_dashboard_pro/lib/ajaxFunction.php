<?php

use WHMCS\Module\Addon\agency_dashboard_pro\Helper;
use WHMCS\Database\Capsule;

require("../../../../init.php");
// require("../../../../includes/clientfunctions.php");
// require("../../../..//includes/domainfunctions.php");




if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
$helper = new Helper();

