<?php

namespace WHMCS\Module\Addon\agency_dashboard_pro;

use WHMCS\Database\Capsule;


use WHMCS\Domains;

class Helper
{
    
}
