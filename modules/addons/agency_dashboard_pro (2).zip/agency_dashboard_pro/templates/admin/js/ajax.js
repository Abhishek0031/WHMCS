$(document).ready(function(){

    // $(document).on('click', '#saveConfig', function() {
    //     // console.log('hiiii');
    //     // $('div.checkbox-group.required :checkbox:checked').length > 0
    //     // data = $('#form').serialize();
    // });



    $(document).on('click', '#install_mod', function() {
        var link = $(this).attr('downloadlink');
       var moddata = $('#moduleData').val();
        // e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "You want to install this module",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: '#DD6B55',
            confirmButtonText: 'Yes',
            cancelButtonText: "No",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function(resp) {
            console.log(resp)

            if (resp) {
                
                
                objectData = {"AjaxCheck" : 'installModule','downloadlink' : link,'moddata': moddata};
                $.ajax({
                    url: '../modules/addons/agency_dashboard_pro/lib/ajaxFunction.php',
                    method: 'POST',
                    data: objectData,
                    dataType: 'json',
                    beforeSend: function(){
                      
                    },
                    success: function(response) {
                      

                        if(response['status'] == 'success'){
                            swal("Success", "Installed Successfully!!", "success", function(value) {
                               location.reload();
                                // swal(`The returned value is: ${value}`);
                            });
                    
                        } else{
                            swal("Fail", "You  Already Have Installed this Module", "error");
                        }

                    },
                    complete: function(){
                      
                    }
                });
            } else {
                console.log('noooooooooooooooooooo')
            }
        });
    });

        
    $('.module-nav-item').click(function(e){
        e.preventDefault();
        var id = $(this).attr('id');
        var type = $(this).attr('data-type');
        var moduleName = $(this).attr('data-module-name');
        var targetElement = "li.module-nav-item#" + id;    
        $(targetElement).addClass('active').siblings('li.module-nav-item').removeClass('active');
        objectData = {"AjaxCheck" : 'checkProductInstallation', "id": id,"moduletype":type,"moduleName": moduleName};
        checkProductinstall(objectData);
    });
    
    $("ul.promenu li:first-child").click();

    // Function triggered when the submit button is clicked
    $('#licenceKeyMSg').hide();
    $('#licsubmit').click(function(){
        
        
        var check=$('#licenceKey').val();
        console.log(check)
        if(check === '') 
        {
            $('#licenceKeyMSg').show();
            return false;
        }
        $('#licenceKeyMSg').html('');
        var licenceKeyVal = $('#licenceKey').val();
        dataObject = {"AjaxCheck" : 'licenceKeyCheck', "licenceKeyValue": licenceKeyVal};
        $(this).val('Loading....');        
        $.ajax({
            url: '../modules/addons/agency_dashboard_pro/lib/ajaxFunction.php',
            method: 'POST',
            data: dataObject,
            dataType: 'json',
            success: function(response) {
                $('#licsubmit').val('Check License');        
           
                if(response['status'] != 'Active'){
                    swal("Fail", "Your Licence Key is "+ response['status'] + "!", "error");
                    return false;
                }

                new_url = location.href + "&action=productlist" ; 
                console.log(new_url);
                window.location.href = new_url;
                // console.log(new_url);
                return false;

                $('.liccontainer').hide();
                productListingHtml = `
                <div class="sidebar">
                <ul class="licsidebar-menu">`;
                var discriptionHtml = '';
                for (x in response){
                if(response[x]['name'] == undefined){
                        continue;
                    }
                        productListingHtml = productListingHtml + "<li><span class='productName' id='" + response[x]['name'] + "'>" + response[x]["name"] + "</span></li>" ;
                } 
            $(document).on('click','.productName',function(){
                id = $(this).attr('id');
                console.log(id)
                for (x in response){
                    if(response[x]['name'] == id){
                        discriptionHtml = `<div class='card'><h2>` + response[x]['name'] + `</h2><p>` + response[x]['description'] + `</p></div>`;
                    }
                } 
                $('.contentMain').html(discriptionHtml);
            })
            productListingHtml = productListingHtml + `</ul></div>`;
                $('#productListing').html(productListingHtml);  
            }
        });
    })
    

});


function checkProductinstall(objectData){
    $.ajax({
        url: '../modules/addons/agency_dashboard_pro/lib/ajaxFunction.php',
        method: 'POST',
        data: objectData,
        // dataType: 'json',
        beforeSend: function(){
            $('.proloader-wrapper').show(); // Hide the proloader        
          },
        success: function(response) {
            // $('.module-nav-item').addClass("changeBody");
            // htmlText = response.name + ":" +  response.description
            // $('.module-heading-bx p').html(htmlText);
        // console.log(response);
        $('.appendProduct').html(response);
        },
        complete: function(){
            $('.proloader-wrapper').hide(); // Hide the proloader
        }
    });
}
