<?php

use WHMCS\Module\Addon\agency_dashboard_pro\Helper;
use WHMCS\Database\Capsule;

require("../../../../init.php");

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
global $whmcs;
$helper = new Helper();

if ($whmcs->get_req_var('AjaxCheck') === 'licenceKeyCheck') {
    $licenceKey = $_POST['licenceKeyValue'];
    $licenceResponce = $helper->checkLicence($licenceKey);
    // echo '<pre>';
    // print_r($licenceResponce); die;
    if($licenceResponce['status'] == 'Active')
    {
        
            if ( ( Capsule::table( 'mod_agencylicence_list' )->where( 'licensekey', $licenceKey )->count() ) !== 0 ) {
                $updatedData = [
                    'status' => $licenceResponce[ 'status' ],
                    'updated_at' => date( 'Y-m-d H:i:s', time() )
                ];
                $result = Capsule::table( 'mod_agencylicence_list' )->where( 'licensekey', $licenceKey )->update( $updatedData );
            } else {

                $insertData = [
                    'licensekey' => $licenceKey,
                    'status' => $licenceResponce[ 'status' ],
                    'created_at' => date( 'Y-m-d H:i:s', time() ),
                    'updated_at' => date( 'Y-m-d H:i:s', time() )
                ];

                $result =  Capsule::table( 'mod_agencylicence_list' )->insert( $insertData );
            }
            // $data = Capsule::table( 'mod_agencylicence_list' )->where( 'licensekey', $licenceKey )->get();
        
          
    }
    $liceStatus = array('status' => $licenceResponce['status']);
    echo json_encode($liceStatus);
    die;

// here we can check the license From $licenceResponce = $helper->checkLicence($array); 
// when we add dynamic product

    if($_POST['licenceKeyValue'] === 'valid'){
    $productlistingData = $helper->productListing();
    $licenceResponce = array_merge($licenceResponce,$productlistingData);
    }
    echo json_encode($licenceResponce);
    exit;
}

if($_POST['AjaxCheck'] === 'checkProductInstallation'){

    $productlistingData = $helper->checkProductInstallation();
    echo json_encode($productlistingData);
    exit;
}

if($_POST['AjaxCheck'] === 'installModule'){

    $res = json_decode(html_entity_decode($_POST['moddata']));

    $filedownload_url = $_POST['downloadlink'];
    // $respo = $helper->downloadfile($filedownload_url);

    $finalRes = $helper->checkmodinstalled_tbl($filedownload_url,$res);
    echo json_encode($finalRes);
    exit;
}

